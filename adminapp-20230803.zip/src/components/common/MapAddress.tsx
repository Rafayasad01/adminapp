import { useEffect, useRef, useState } from 'react';
import { Loader } from '@googlemaps/js-api-loader';

import assets from '../../assets';

type Props = {
  center: google.maps.LatLngLiteral;
  zoom: number;
};

const loader = new Loader({
  apiKey: 'AIzaSyBp7k8-SYDkEkhcGbXQ9f_fAXPXmwmlvUQ',
  version: 'weekly',
});

const address = "Room 704, Dilkukhan Building, Main Tariq Road, block # 3, P.E.C.H.S, Karachi";

console.log('loader::::::::', loader)

function MapAddress({ center, zoom }: Props) {
  const mapRef = useRef<HTMLDivElement>(null);
  const [map, setMap] = useState<google.maps.Map>();
  const [lat, setLat] = useState<number | null>(null);
  const [lng, setLng] = useState<number | null>(null);
  //const markerRef = useRef<google.maps.Marker>();

  useEffect(() => {

    loader.load().then(async (e) => {
      const options: google.maps.MapOptions = {
        center,
        zoom,
        mapTypeId: 'roadmap',
        mapTypeControl: false,
        streetViewControl: false,
        zoomControl: false,
        fullscreenControl: false,
        scaleControl: false,
      };
      const mapInstance = new google.maps.Map(mapRef.current!, options);
      setMap(mapInstance);
      // const marker = new google.maps.Marker({
      //   position: center,
      //   map,
      //   title: 'Location',
      //   icon: assets.images.iconMap,
      //   draggable: false,
      //   animation: google.maps.Animation.DROP,
      // });
      // markerRef.current = marker;
    });
  }, [loader.apiKey]);

  useEffect(() => {
    if (map && address) {
      const geocoder = new google.maps.Geocoder();
      geocoder.geocode({ address }, (results, status) => {
        if (status === 'OK') {
          const { lat, lng } = results[0].geometry.location;
          setLat(lat());
          setLng(lng());
          map.setCenter({ lat, lng });
        } else {
          console.error('Geocode was not successful for the following reason:', status);
        }
      });
    }
  }, [map, address]);

  return (
    <div
      ref={mapRef}
      style={{ height: '100%', width: '100%', borderRadius: '0.5rem' }}
    />
  );
}

export default MapAddress;
