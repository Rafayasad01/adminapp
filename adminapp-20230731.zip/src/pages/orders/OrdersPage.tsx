/* eslint-disable react/jsx-props-no-spreading */
import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import IconButton from '@mui/material/IconButton';
import Divider from '@mui/material/Divider';
import FormControl from '@mui/material/FormControl';
import Input from '@mui/material/Input';
import InputAdornment from '@mui/material/InputAdornment';
import { SelectChangeEvent } from '@mui/material';
import SearchIcon from '@mui/icons-material/Search';
import Checkbox from '@mui/material/Checkbox';
import CheckBoxOutlineBlankOutlinedIcon from '@mui/icons-material/CheckBoxOutlineBlankOutlined';
import CheckBoxOutlinedIcon from '@mui/icons-material/CheckBoxOutlined';

import MoreVertIcon from '@mui/icons-material/MoreVert';
import AddOutlinedIcon from '@mui/icons-material/AddOutlined';
//import Pagination from '@mui/material/Pagination';
//import Stack from '@mui/material/Stack';
import order from '../../services/adminapp/adminOrders';
import dayjs from 'dayjs';
import TablePagination from '@mui/material/TablePagination';
import ActionMenu from '../../components/common/ActionMenu';
import { ORDER_STATUSES, ORDER_STATUS_IN_CANCELLED, ORDER_STATUS_IN_DELIVERED, ORDER_STATUS_IN_DELIVERY, ORDER_STATUS_NEW, ORDER_STATUS_PICKED_UP, ORDER_STATUS_PROCESSING } from '../../utils/constants';
import TopBar from '../../components/common/TopBar';
import { useAppSelector } from '../../redux/redux-hooks';



const actionMenuOptions = ['View'];
function OrdersPage() {
  const authState: any = useAppSelector((state) => state.authState);
  const navigate = useNavigate();
  const [search, setSearch] = useState('');
  const [status, setStatus] = useState('status');
  const [time, setTime] = useState('time');
  const [page, setPage] = useState(0);
  const [total, setTotal] = useState(0);
  const [list, setList] = useState<any>([]);
  const [rowsPerPage, setRowsPerPage] = React.useState(10);
  const [actionMenuItemid, setActionMenuItemid] = React.useState("");
  const [actionMenuAnchorEl, setActionMenuAnchorEl] = useState<null | HTMLElement>(null);
  const actionMenuOpen = Boolean(actionMenuAnchorEl);


  const handleChangePage = (
    event: React.MouseEvent<HTMLButtonElement> | null,
    newPage: number,
  ) => {
    setPage(newPage);
    //offset? ,limit rowsperpage hoga ofset page * rowsperPage
    if (search === "" || search === null || search === undefined) {
      order.getListService(authState.user.tenant, newPage, rowsPerPage).then(item => {
        setList(item.data.data.list.map((item: any) => ({ ...item, isSelected: false, orderStatus: item.status })));
        setTotal(item.data.data.total);
      });
    } else {
      order.searchService(authState.user.tenant, search, newPage, rowsPerPage).then(item => {
        setList(item.data.data.list.map((item: any) => ({ ...item, isSelected: false, orderStatus: item.status })));
        setTotal(item.data.data.total);
      });
    }
    // order.searchService(search, newPage, rowsPerPage).then(item => {
    //   setList(item.data.data.list.map((item: any) => ({ ...item, isSelected: false, orderStatus: item.status })));
    //   setTotal(item.data.data.total);
    // });
  };
  const handleChangeRowsPerPage = (
    event: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>,
  ) => {
    const newRowperPage = parseInt(event.target.value, 10);
    const newPage = 0;
    setRowsPerPage(newRowperPage);
    setPage(newPage);
    if (search === "" || search === null || search === undefined) {
      order.getListService(authState.user.tenant, newPage, rowsPerPage).then(item => {
        setList(item.data.data.list.map((item: any) => ({ ...item, isSelected: false, orderStatus: item.status })));
        setTotal(item.data.data.total);
      });
    } else {
      order.searchService(authState.user.tenant, search, newPage, rowsPerPage).then(item => {
        setList(item.data.data.list.map((item: any) => ({ ...item, isSelected: false, orderStatus: item.status })));
        setTotal(item.data.data.total);
      });
    }
    // order.searchService(search, page, rowsPerPage).then(item => {
    //   setList(item.data.data.list.map((item: any) => ({ ...item, isSelected: false, orderStatus: item.status })));
    //   setTotal(item.data.data.total);
    // });
  };
  const addRouteHandler = () => {
    navigate('create');
  };

  const handleClickSearch = (event: any) => {
    const searchTxt = event.target.value as string;
    setSearch(searchTxt);
    setPage(0);
    order.searchService(authState.user.tenant, searchTxt, page, rowsPerPage).then(item => {
      setList(item.data.data.list.map((item: any) => ({ ...item, isSelected: false, orderStatus: item.status })));
      setTotal(item.data.data.total);
    })
  };

  // const handleStatusChange = (event: SelectChangeEvent) => {
  //   setStatus(event.target.value as string);
  // };

  // const handleTimeChange = (event: SelectChangeEvent) => {
  //   setTime(event.target.value as string);
  // };
  // const changeStatusHandler = (event: any) => {
  //   setStatus(event.target.value as string);
  // };

  useEffect(() => {
    order.getListService(authState.user.tenant, page, rowsPerPage).then(item => {
      //console.log(item.data.data);
      setList(item.data.data.list.map((item: any) => ({ ...item, isSelected: false, orderStatus: item.status })));
      setTotal(item.data.data.total);
    });
  }, []);

  const manuHandler = (option: string) => {
    let doOption = '';
    if (option === 'Edit') {
      doOption = 'edit';
    } else if (option === 'View') {
      doOption = 'view';
    } else {
      doOption = 'download';
    }
    navigate(`${doOption}/${actionMenuItemid}`);
    //console.log('actionMenuItemid', actionMenuItemid)
  }

  const getStatusTag = (status: string) => {
    let tag = "";
    if (status === ORDER_STATUS_NEW) {
      tag = "blue";
    } else if (status === ORDER_STATUS_PICKED_UP) {
      tag = "purple";
    } else if (status === ORDER_STATUS_PROCESSING) {
      tag = "green";
    } else if (status === ORDER_STATUS_IN_DELIVERY) {
      tag = "orange";
    } else if (status === ORDER_STATUS_IN_DELIVERED) {
      tag = "yellow";
    } else if (status === ORDER_STATUS_IN_CANCELLED) {
      tag = "red";
    }
    return tag;
  }
  const setOrderStatus = (status: string) => {
    const newStatuses = [...ORDER_STATUSES].map(([key, value]) => ({ key, value }));
    const newStatus = newStatuses.filter(s => s.key === status);
    return newStatus[0].value.title;
  }
  return (
    <>
      {actionMenuAnchorEl && (
        <ActionMenu open={actionMenuOpen} anchorEl={actionMenuAnchorEl} setAnchorEl={setActionMenuAnchorEl} options={actionMenuOptions} callback={manuHandler} />
      )}
      <TopBar title="Orders" />
      <div className="container mt-5">
        <div className="w-full rounded-lg bg-white shadow-lg">
          <div className="grid grid-cols-12 px-4 py-5">
            <div className="col-span-3">
              <span className="font-open-sans text-xl font-semibold text-[#252733]">
                All Orders
              </span>
            </div>
            <div className="col-span-6">
              <div className="flex flex-row gap-3">
                <FormControl
                  className="search-grey-outline placeholder-grey w-60"
                  variant="filled"
                >
                  <Input
                    className="input-with-icon after:border-b-neutral-900"
                    id="search"
                    type="text"
                    placeholder="Search"
                    onKeyDown={(
                      event: React.KeyboardEvent<
                        HTMLInputElement | HTMLTextAreaElement
                      >
                    ) => {
                      if (event.key === 'Enter') {
                        handleClickSearch(event);
                      }

                    }}
                    endAdornment={
                      <InputAdornment position="end">
                        <Divider
                          sx={{ height: 28, m: 0.5 }}
                          orientation="vertical"
                        />
                        <IconButton aria-label="toggle password visibility">
                          <SearchIcon className="text-[#6A6A6A]" />
                        </IconButton>
                      </InputAdornment>
                    }
                    disableUnderline
                  />
                </FormControl>
                {/* <Select
                  className="select-grey-outline h-10 w-36"
                  labelId="demo-simple-select-label"
                  id="demo-simple-select"
                  value={status}
                  onChange={handleStatusChange}
                >
                  <MenuItem value="status">Status</MenuItem>
                </Select>
                <Select
                  className=" select-grey-outline mr-3 h-10 w-36"
                  labelId="demo-simple-select-label"
                  id="demo-simple-select"
                  value={time}
                  onChange={handleTimeChange}
                >
                  <MenuItem value="time">Time</MenuItem>
                </Select> */}
              </div>
            </div>
            <div className="col-span-3">
              <div className="flex flex-row">
                {/* <Button variant="contained" className="btn-black-outline mr-3">
                  Export to CSV
                </Button>
                <Button
                  variant="contained"
                  className="btn-black-fill btn-icon"
                  onClick={addRouteHandler}
                >
                  <AddOutlinedIcon /> Add New
                </Button> */}
              </div>
            </div>
          </div>
          <div className="mt-3 grid grid-cols-none">
            <table className="table-border table-auto">
              <thead>
                <tr>
                  <th className="w-[22%]">Customers</th>
                  <th>Pickup Time</th>
                  <th>Drop-off Time</th>
                  <th>Amount</th>
                  <th >Status</th>
                  <th>Order ID</th>
                  <th>&nbsp;</th>
                </tr>
              </thead>
              <tbody>
                {list && list.map((order: any, index: number) => {
                  return (
                    <tr key={order.id}>
                      <td>
                        <div className="flex flex-col">
                          <span className="text-sm font-semibold text-[#1A1A1A]">
                            {order.user.firstName} {order.user.lastName}
                          </span>
                          <span className="text-xs font-normal text-[#6A6A6A]">
                            {order.user.email}
                          </span>
                          <span className="text-xs font-normal text-[#6A6A6A]">
                            {order.userAddress.address}
                          </span>
                        </div>
                      </td>
                      <td>
                        <div className="flex flex-col">
                          <span className="text-sm font-normal text-[#1A1A1A]">
                            {dayjs(order.pickupDateTime)?.format('hh:mm:ssA')} - {dayjs(order.pickupDateTime).add(1, 'hour').format('hh:mm:ssA')}
                          </span>
                          <span className="text-xs font-normal text-[#6A6A6A]">
                            {dayjs(order.pickupDateTime)?.format('ddd, MMM DD, YYYY')}
                          </span>
                        </div>
                      </td>
                      <td>
                        <div className="flex flex-col">
                          <span className="text-sm font-normal text-[#1A1A1A]">
                            {dayjs(order.dropDateTime)?.format('hh:mm:ssA')} - {dayjs(order.dropDateTime).add(1, 'hour').format('hh:mm:ssA')}
                          </span>
                          <span className="text-xs font-normal text-[#6A6A6A]">
                            {dayjs(order.dropDateTime)?.format('ddd, MMM DD, YYYY')}
                          </span>
                        </div>
                      </td>
                      <td className="text-sm font-semibold text-[#1A1A1A]">
                        ${order.grandTotal}
                      </td>
                      <td>
                        <span className={`badge badge-${getStatusTag(order.status)}`}>{setOrderStatus(order.status)}</span>
                      </td>
                      <td>{order.orderNumber}</td>
                      <td>
                        <IconButton
                          className="btn-dot"
                          aria-label="more"
                          id="long-button"
                          aria-controls={actionMenuOpen ? 'long-menu' : undefined}
                          aria-expanded={actionMenuOpen ? 'true' : undefined}
                          aria-haspopup="true"
                          onClick={(event: React.MouseEvent<HTMLElement>) => {
                            setActionMenuItemid(list[index].id)
                            setActionMenuAnchorEl(event.currentTarget);
                          }}
                        >
                          <MoreVertIcon />
                        </IconButton>
                      </td>
                    </tr>
                  )
                })}
              </tbody>
            </table>
          </div>
          <div className='w-[100%] mt-3 flex justify-center py-3'>
            <TablePagination
              component="div"
              count={total}
              page={page}
              onPageChange={handleChangePage}
              rowsPerPage={rowsPerPage}
              onRowsPerPageChange={handleChangeRowsPerPage}
            />
          </div>
        </div>
      </div>
    </>
  );
}

export default OrdersPage;
