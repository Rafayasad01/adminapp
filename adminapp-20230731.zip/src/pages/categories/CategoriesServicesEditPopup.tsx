import React, { useState, useEffect } from 'react';
import Dialog from '@mui/material/Dialog';
import Button from '@mui/material/Button';
import FormControl from '@mui/material/FormControl';
import Input from '@mui/material/Input';
import CloseOutlinedIcon from '@mui/icons-material/CloseOutlined';
import FileUploadOutlinedIcon from '@mui/icons-material/FileUploadOutlined';
import IconButton from '@mui/material/IconButton';
import TextField from '@mui/material/TextField';
import { useForm } from "react-hook-form";

import '../../assets/css/PopupStyle.css';
import { CategoryService } from '../../interfaces/category.interface';

type Props = {
  openFormDialog: boolean;
  setOpenFormDialog: React.Dispatch<React.SetStateAction<boolean>>;
  formData: any;
  callback: Function;
};

function CategoriesServicesEditPopup({
  openFormDialog,
  setOpenFormDialog,
  formData,
  callback
}: Props) {
  const [image, setImage] = useState<any>(null);
  const [imageName, setImageName] = useState<string>('');

  const { register, handleSubmit, watch, formState: { errors }, control } = useForm<CategoryService>();
  const onSubmit = (data: CategoryService) => {
    data.icon = image;
    setOpenFormDialog(false);
    callback(data);
  };

  const handleFormClose = () => setOpenFormDialog(false);
  const handleRemoveImage = () => {
    setImage('');
    setImageName('');
  };

  const handleFileChange = (event: any) => {
    setImage(event.target.files[0]);
    setImageName(event.target.files[0].name);
  };

  useEffect(() => {
    let icon = formData.icon.split("/").slice(-1)[0];
    const regexExp = /[a-z,0-9,-]{36}/;
    if (regexExp.test(icon)) {
      icon = icon.split("-").splice(5)[0];
    }
    setImageName(icon);
  }, []);

  return (
    <Dialog
      open={openFormDialog}
      onClose={handleFormClose}
      PaperProps={{
        className: 'Dialog',
        style: { maxWidth: '100%', maxHeight: 'auto' },
      }}
    >
      <div className="Content">
        <form onSubmit={handleSubmit(onSubmit)}>
          <div className="FormHeader">
            <span className="Title">Edit Services</span>
          </div>
          <div className="FormBody">
            <div className="FormField">
              <FormControl className="FormControl" variant="standard">
                <label className="FormLabel">Service Name</label>
                <Input
                  className="FormInput"
                  id="name"
                  {...register("name", { required: "Name is required", value: formData.name })}
                  disableUnderline
                />
                {errors.name && <span role="alert">{errors.name?.message}</span>}
              </FormControl>
            </div>
            <div className="FormFields">
              <FormControl className="FormControl" variant="standard">
                <label className="FormLabel">Min Order Quantity</label>
                <Input
                  className="FormInput"
                  id="name"
                  type="number"
                  {...register("quantity", { required: "Quantity is required", value: formData.quantity })}
                  disableUnderline
                />
                {errors.quantity && <span role="alert">{errors.quantity?.message}</span>}
              </FormControl>
              <FormControl className="FormControl" variant="standard">
                <label className="FormLabel">Price</label>
                <Input
                  className="FormInput"
                  id="name"
                  type="number"
                  {...register("price", { required: "Price is required", value: formData.price })}
                  disableUnderline
                />
                {errors.price && <span role="alert">{errors.price?.message}</span>}
              </FormControl>
            </div>
            <div className="FormField">
              <FormControl className="FormControl" variant="standard">
                <label className="FormLabel">
                  Description{' '}
                  <span className="SubLabel">Write 25-250 Characters</span>
                </label>
                <TextField
                  className="FormTextarea"
                  id="outlined-multiline-static"
                  multiline
                  rows={2}
                  defaultValue=""
                  placeholder="Write Description"
                  {...register("desc", { value: formData.desc })}
                />
              </FormControl>
            </div>
            <div className="FormField">
              <label className="FormLabel">Upload Image</label>
              <div className="ImageBox">
                <input
                  accept="image/*"
                  style={{ display: 'none' }}
                  id="raised-button-file"
                  type="file"
                  onChange={(
                    event: React.InputHTMLAttributes<HTMLInputElement>
                  ) => {
                    handleFileChange(event);
                  }}
                />
                <label htmlFor="raised-button-file" className="ImageLabel">
                  <Button component="span" className="ImageBtn">
                    <FileUploadOutlinedIcon sx={{ marginRight: '0.5rem' }} />
                    Upload image
                  </Button>
                </label>
                {imageName ? (
                  <div className="ShowImageBox">
                    <label className="ShowImageLabel">{imageName}</label>
                    <IconButton className="btn-dot" onClick={handleRemoveImage}>
                      <CloseOutlinedIcon
                        sx={{
                          color: '#1D1D1D',
                          fontSize: '1rem',
                          lineHeight: '1.5rem',
                        }}
                      />
                    </IconButton>
                  </div>
                ) : (
                  ''
                )}
              </div>
            </div>
          </div>
          <div className="FormFooter">
            <Button
              className="btn-black-outline"
              onClick={handleFormClose}
              sx={{
                marginRight: '0.5rem',
                padding: '0.375rem 1.5rem !important',
              }}
            >
              Cancel
            </Button>
            <Input
              type="submit"
              value="Update"
              className="btn-black-fill"
              sx={{
                padding: '0.375rem 2rem !important',
              }}
            />
          </div>
        </form>
      </div>
    </Dialog>
  );
}

export default CategoriesServicesEditPopup;
